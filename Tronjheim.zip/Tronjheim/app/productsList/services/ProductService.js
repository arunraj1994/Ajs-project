'use strict';

TronjheimApp.service('ProductService', ['$rootScope', '$http',
    '$q',
    'PRODUCT_CONSTANTS', 'ProductDataFactory',
    function($rootScope, $http, $q, PRODUCT_CONSTANTS, ProductDataFactory) {

        this.getProducts = function() {
            var deferred = $q.defer();
            var url = PRODUCT_CONSTANTS.PRODUCT_URL;
			console.log("Product API Call Made.........");
			$http.get(url, {cache: false})
			.success(
				function(data) {
					ProductDataFactory.setApiHits();
					ProductDataFactory.setData(data.deals);
					deferred.resolve(data);
					$rootScope.isLoader = false;
				})
			.error(
				function(data) {
					deferred.reject(data);
					$rootScope.isLoader = false;
					$rootScope.isError = true;
				});
			return deferred.promise;
		};

    }
]);
