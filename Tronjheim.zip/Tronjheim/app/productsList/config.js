'use strict';

var TronjheimApp = angular.module('TronjheimApp');

TronjheimApp.constant('PRODUCT_CONSTANTS', {
	"PRODUCT_URL": "http://starlord.hackerearth.com/cognizantinternal/dealshub",
    "ERROR" : "Url not Found!"
});