'use strict';

/**
 * @ngdoc function
 * @name TronjheimApp.controller:ProductListViewController
 * @description
 * # ProductListViewController
 * Controller of the TronjheimApp
 */
 
TronjheimApp.controller('ProductListViewController', ['$rootScope',
        '$scope',
		'filterFilter',
        '$state',
        '$timeout',
        '$window',
		'$location',
        'ProductService',
		'ProductDataFactory',        
        function($rootScope,
            $scope,
			filterFilter,
            $state,
            $timeout,
            $window,
			$location,
            ProductService,
			ProductDataFactory){
				
			$scope.search = '';
			$scope.propertyName = '';
			$scope.reverse = null;
			$scope.suggestions = [];
			$scope.currentPage = 0;
			$scope.totalItems = 0;
			$scope.entryLimit = 0; // items per page
			$scope.noOfPages = 0;
			$scope.items = [];
			$scope.apiHits = '';
			$scope.apiRateLimit = '';
			$scope.totalLikeCount = 0;
			
				
			function init(){
				renderGameList();
				setPagination();
				getDataForAutoComplete();
			}
			
			function renderGameList(){
				var productData, ProductsFromStorage, i, finalPrice, temp1, temp2, temp3, rating, tempArr=[];
				
				if($window.localStorage.getItem("Products") === null){
					productData = ProductDataFactory.getData();
					for(i=0; i<productData.length; i++){
						if(productData[i].name){
							finalPrice = productData[i].discount;
							temp1 = parseFloat(finalPrice.replace("%", ""));
							temp2 = (productData[i].actual_price * temp1)/100;
							temp3 = productData[i].actual_price - temp2;
							productData[i].finalPrice = parseFloat(temp3.toFixed(2));
							productData[i].rating = parseFloat(productData[i].rating);
							productData[i].likes = 0;
							tempArr.push(productData[i]);
						}
					}
					$scope.items = tempArr;
					$window.localStorage.setItem("Products", JSON.stringify($scope.items));
					$window.localStorage.setItem("PRODUCT_LIKE_COUNT", JSON.stringify($scope.totalLikeCount));				
				}
				else{
					ProductsFromStorage = JSON.parse($window.localStorage.getItem('Products'));
					$scope.totalLikeCount = JSON.parse($window.localStorage.getItem('PRODUCT_LIKE_COUNT'));
					ProductDataFactory.setData(ProductsFromStorage);
					$scope.items = ProductsFromStorage;					
					$rootScope.isLoader = false;
				}
				$scope.apiHits = ProductDataFactory.getApiHits();
			}
			
			// Set data for pagination controls				
			function setPagination(){
				$scope.propertyName = 'title';
				$scope.reverse = false;
				$scope.currentPage = 1;
				$scope.totalItems = $scope.items.length;
				$scope.entryLimit = 9; // items per page
				$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);
			}
				
			function getDataForAutoComplete(){
				for(var i=0; i< $scope.items.length; i++){
					$scope.suggestions.push($scope.items[i].name);
					$scope.suggestions.push($scope.items[i].provider);
					$scope.suggestions.push($scope.items[i].rating);
					$scope.suggestions.push($scope.items[i].discount);
					$scope.suggestions.push($scope.items[i].actual_price);
					$scope.suggestions.push($scope.items[i].finalPrice);
				}
				
				$scope.suggestions = $scope.suggestions.filter (function (value, index, array) { 
					return array.indexOf (value) == index;
				});				
			}

			
			$scope.resetSearch = function(){
				$scope.search = null;
			}
			
			$scope.resetFilters = function () {
				$scope.search = '';
				$scope.propertyName = 'title';
				$scope.reverse = false;
			};
			
			
			$scope.sortBy = function(propertyName, bool){
				$scope.propertyName = propertyName;
				$scope.reverse = bool;
			}
			
			$scope.updateLikes = function(selectedItem){
				var name = selectedItem.name;
				var no = selectedItem.likes;
				no++;
				for(var i=0; i < $scope.items.length; i++){
					if($scope.items[i].name === name){
						$scope.items[i].likes = no;
						break;
					}
				}
				$scope.totalLikeCount++;
				$window.localStorage.setItem("Products", JSON.stringify($scope.items));
				$window.localStorage.setItem("PRODUCT_LIKE_COUNT", JSON.stringify($scope.totalLikeCount));				
			}

			// $watch search to update pagination
			$scope.$watch('search', function (newVal, oldVal) {
				$scope.filtered = filterFilter($scope.items, newVal);
				$scope.totalItems = $scope.filtered.length;
				$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);
				$scope.currentPage = 1;
			}, true);
			
			init();
}]);