'use strict';

TronjheimApp.factory('ProductDataFactory', function() {
    var factory = {};
	factory.data = '';
	factory.apiHits = 0;
	
        factory.setData = function (data) {
			factory.data = data;
        };
		
		factory.getData = function () {
            return factory.data;
        };
		
		factory.getApiHits = function () {
            return factory.apiHits;
        };
		factory.setApiHits = function () {
            factory.apiHits += 1;
        };
		
	return factory;
	
  });
