'use strict';
/**
/**
    * @ngdoc overview
    * @name TronjheimApp
    * @name TronjheimApp
    * @description
    * # TronjheimApp
    *
    * Main module of the application.
*/
angular.module('TronjheimApp', [
        'ui.router',
        'ngSanitize',
		'ui.bootstrap'
    ])     
    .run(['$rootScope',  '$injector',  '$state', '$window', function($rootScope, $injector, $state, $window) {
        $rootScope.isLoader = true;
		$rootScope.isError = false;	
    }])

    .config(function($stateProvider, $httpProvider, $urlRouterProvider, $provide) {
        
		$urlRouterProvider.otherwise('/');
		
        $stateProvider
            .state('home', {
				url: '/',
                views: {                    
                    'ProductListView': {
                        templateUrl: 'productsList/views/ProductListView.html',
						controller: 'ProductListViewController'
                    }
                },
				resolve: {
                    ProductService: 'ProductService',
										
					/*Get Translated Data on load of appl'n*/
					getProductsResponse: function(ProductService) {
						var dataFromStore = window.localStorage.getItem('Products');
						if(dataFromStore === null || dataFromStore === 'null'){
							return ProductService.getProducts();
						}
						else{
							return null;
						}
					}					
                }
            });
			        
    });
